package com.example.atlasai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var setupGroup: View
    private lateinit var mainGroup: View
    private lateinit var nameInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var statusText: TextView
    private lateinit var logText: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var micButton: Button
    private lateinit var sms: SmsHelper

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var gemini: GeminiClient? = null
    private var userName = ""
    private var pendingSms: Pair<SmsHelper.Contact, String>? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* результат учтём при следующем нажатии */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("atlas", Context.MODE_PRIVATE)
        sms = SmsHelper(this)

        setupGroup = findViewById(R.id.setupGroup)
        mainGroup = findViewById(R.id.mainGroup)
        nameInput = findViewById(R.id.nameInput)
        keyInput = findViewById(R.id.keyInput)
        statusText = findViewById(R.id.statusText)
        logText = findViewById(R.id.logText)
        logScroll = findViewById(R.id.logScroll)
        micButton = findViewById(R.id.micButton)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                ttsReady = true
            }
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val name = nameInput.text.toString().trim()
            val key = keyInput.text.toString().trim()
            if (name.isEmpty() || key.isEmpty()) {
                Toast.makeText(this, "Введите имя и ключ", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString("name", name).putString("key", key).apply()
            startAssistant(greet = true)
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            nameInput.setText(prefs.getString("name", ""))
            mainGroup.visibility = View.GONE
            setupGroup.visibility = View.VISIBLE
        }
        micButton.setOnClickListener { listen() }

        requestPermissionsIfNeeded()

        if (prefs.getString("name", null) != null && prefs.getString("key", null) != null) {
            startAssistant(greet = false)
        }
    }

    // ---------- старт ----------

    private fun startAssistant(greet: Boolean) {
        userName = prefs.getString("name", "") ?: ""
        gemini = GeminiClient(prefs.getString("key", "") ?: "", userName)
        setupGroup.visibility = View.GONE
        mainGroup.visibility = View.VISIBLE
        if (greet) reply("Здравствуйте, $userName. Атлас на связи.")
    }

    private fun requestPermissionsIfNeeded() {
        val needed = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS
        ).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) permLauncher.launch(needed.toTypedArray())
    }

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    // ---------- распознавание речи ----------

    private fun listen() {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            requestPermissionsIfNeeded()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Распознавание речи недоступно на этом устройстве, $userName.")
            return
        }
        tts?.stop()

        val rec = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        statusText.text = "Слушаю…"
        micButton.isEnabled = false
        rec.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            micButton.isEnabled = true
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text.isNullOrBlank()) {
                statusText.text = "Готов"
            } else {
                handle(text)
            }
        }

        override fun onError(error: Int) {
            micButton.isEnabled = true
            statusText.text = "Готов"
            if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            ) reply("Не расслышал, $userName.")
            else reply("Ошибка распознавания речи, $userName.")
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { statusText.text = "Думаю…" }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ---------- обработка команд ----------

    private val smsRegex = Regex(
        "^(?:отправь|напиши|пошли)\\s+(?:смс|sms|сообщение)?\\s*(?:контакту\\s+)?(\\S+)\\s+(.+)$",
        RegexOption.IGNORE_CASE
    )
    private val openRegex = Regex("^(?:открой|запусти|включи)\\s+(.+)$", RegexOption.IGNORE_CASE)

    private fun handle(text: String) {
        log("Вы: $text")
        val t = text.trim()

        // 1) подтверждение отправки SMS
        pendingSms?.let { (contact, body) ->
            pendingSms = null
            if (t.lowercase().startsWith("да") || t.lowercase().contains("отправ")) {
                trySend(contact, body)
            } else {
                reply("Отменил, $userName.")
            }
            return
        }

        // 2) SMS
        smsRegex.find(t)?.let { m ->
            if (!has(Manifest.permission.READ_CONTACTS) || !has(Manifest.permission.SEND_SMS)) {
                requestPermissionsIfNeeded()
                reply("Нужны разрешения на контакты и SMS, $userName.")
                return
            }
            val who = m.groupValues[1]
            val body = m.groupValues[2]
            val contact = sms.findContactFuzzy(who)
            if (contact == null) {
                reply("Не нашёл контакт $who, $userName.")
            } else {
                pendingSms = contact to body
                reply("Отправить ${contact.name}: $body? Скажите да или нет.")
            }
            return
        }

        // 3) открыть приложение
        openRegex.find(t)?.let { m ->
            openApp(m.groupValues[1].trim())
            return
        }

        // 4) всё остальное - Gemini
        askGemini(t)
    }

    private fun trySend(contact: SmsHelper.Contact, body: String) {
        try {
            sms.send(contact.number, body)
            reply("Сообщение отправлено, $userName.")
        } catch (e: Exception) {
            reply("Не удалось отправить сообщение, $userName.")
        }
    }

    private fun openApp(query: String) {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
        val q = query.lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        val launch = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (launch != null) {
            reply("Открываю ${match.loadLabel(pm)}, $userName.")
            startActivity(launch)
        } else {
            reply("Не нашёл приложение $query, $userName.")
        }
    }

    private fun askGemini(text: String) {
        val client = gemini ?: return
        statusText.text = "Думаю…"
        lifecycleScope.launch {
            val answer = client.ask(text)
            reply(answer)
        }
    }

    // ---------- вывод ----------

    private fun reply(text: String) {
        log("Атлас: $text")
        statusText.text = "Готов"
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "atlas")
    }

    private fun log(line: String) {
        logText.append(line + "\n\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
