package com.example.atlasai

import android.content.Context
import android.provider.ContactsContract
import android.telephony.SmsManager

/** Поиск контакта и отправка SMS. Нужны READ_CONTACTS и SEND_SMS. */
class SmsHelper(private val context: Context) {

    data class Contact(val name: String, val number: String)

    fun findContact(query: String): Contact? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"), null
        ) ?: return null
        cursor.use {
            if (it.moveToFirst()) return Contact(it.getString(0), it.getString(1))
        }
        return null
    }

    /** Голос даёт падежи («Маме», «Максиму»): пробуем слово целиком и с отрезанным окончанием. */
    fun findContactFuzzy(spoken: String): Contact? {
        val word = spoken.trim()
        for (cut in 0..2) {
            if (word.length - cut < 3) break
            findContact(word.dropLast(cut))?.let { return it }
        }
        return null
    }

    fun send(number: String, text: String) {
        val sms = if (android.os.Build.VERSION.SDK_INT >= 31)
            context.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        val parts = sms.divideMessage(text)
        sms.sendMultipartTextMessage(number, null, parts, null, null)
    }
}
