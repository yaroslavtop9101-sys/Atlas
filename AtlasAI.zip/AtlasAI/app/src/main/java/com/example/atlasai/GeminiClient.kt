package com.example.atlasai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Клиент Gemini с поиском Google и памятью диалога.
 *
 * Зависимость: org.jetbrains.kotlinx:kotlinx-coroutines-android
 * ВАЖНО: ключ в приложении временный, для тестов. Для релиза - свой сервер-прокси.
 *
 * Использование: lifecycleScope.launch { val text = client.ask("...") }
 */
class GeminiClient(private val apiKey: String, private val userName: String) {

    // Проверь актуальное имя модели в документации Gemini API
    private val model = "gemini-2.5-flash"

    private val history = JSONArray()
    private val mutex = Mutex() // запросы идут строго по очереди, история не портится

    private val systemPrompt = """
        Ты Атлас, голосовой ИИ-ассистент в стиле Джарвиса.
        Пользователя зовут $userName. Обращайся к нему строго по имени.
        Отвечай по-русски, кратко (1-3 предложения), без markdown и списков,
        потому что ответ будет произнесён вслух. Для свежих фактов используй поиск.
    """.trimIndent()

    /** Можно вызывать из любого потока: переключение на IO внутри. */
    suspend fun ask(prompt: String): String = mutex.withLock {
        withContext(Dispatchers.IO) { request(prompt) }
    }

    /** Забыть диалог (например, по команде «забудь всё»). */
    suspend fun reset() = mutex.withLock {
        while (history.length() > 0) history.remove(0)
    }

    private fun request(prompt: String): String {
        // Работаем с копией: в настоящую историю пишем только после успешного ответа
        val contents = JSONArray(history.toString()).put(turn("user", prompt))

        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", systemPrompt))))
            put("contents", contents)
            put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        return try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) {
                // Подробности только в лог, вслух - короткая фраза
                val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()
                android.util.Log.w("GeminiClient", "HTTP $code: ${err.take(500)}")
                return errorPhrase(code)
            }

            val json = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).readText())
            val answer = extractAnswer(json)
                ?: return "Не удалось получить ответ, $userName. Попробуйте переформулировать."

            history.put(turn("user", prompt))
            history.put(turn("model", answer))
            trimHistory()
            answer
        } catch (e: IOException) {
            "Нет связи с интернетом, $userName."
        } catch (e: JSONException) {
            android.util.Log.w("GeminiClient", "Bad response", e)
            "Не удалось разобрать ответ сервера, $userName."
        } finally {
            conn.disconnect()
        }
    }

    /** Достаёт текст; null, если кандидатов нет (блокировка) или текст пуст. */
    private fun extractAnswer(json: JSONObject): String? {
        val candidates = json.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) return null
        val parts = candidates.getJSONObject(0)
            .optJSONObject("content")?.optJSONArray("parts") ?: return null
        val text = buildString {
            for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
        }.trim()
        return text.ifEmpty { null }
    }

    private fun errorPhrase(code: Int): String = when (code) {
        400 -> "Запрос отклонён, $userName. Проверьте настройки ключа или модели."
        401, 403 -> "Ключ API не подходит или доступ запрещён, $userName."
        404 -> "Модель не найдена, $userName. Нужно обновить её название."
        429 -> "Лимит запросов исчерпан, $userName. Подождите немного."
        in 500..599 -> "Сервер Gemini сейчас недоступен, $userName."
        else -> "Ошибка сервера $code, $userName."
    }

    private fun turn(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    // Храним последние ~20 реплик, удаляя парами (user + model),
    // чтобы история всегда начиналась с реплики пользователя
    private fun trimHistory() {
        while (history.length() > 20) {
            history.remove(0)
            history.remove(0)
        }
    }
}
